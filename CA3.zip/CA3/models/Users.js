const mongoose = require('mongoose');

// mongoose.connect("mongodb://localhost:27017/userDB");

const userSchema = new mongoose.Schema({
   
    firstname: String,
    lastname: String, 
    email: String,
    password: String
});

const User = new mongoose.model("user", userSchema);

module.exports = User;