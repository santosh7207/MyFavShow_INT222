const nodemailer = require('nodemailer');
const mailGun = require('nodemailer-mailgun-transport');

const auth = {
    auth: {
        api_key: 'key-84762af04be4d52b11b60ceb2158ea46',
        domain: 'sandboxc999c425747e4aa4a217f3932ed8d34c.mailgun.org'
    }
};

const transporter = nodemailer.createTransport(mailGun(auth));


const sendMail = (email, subject, text, cb) => {

    const mailOptions = {

        from: email,
        to: 'saisantosh8522892638@gmail.com',
        subject: subject,
        text: text
    };
    
    transporter.sendMail(mailOptions, function(err, data) {
        if (err) {
            cb(err, null);
        } else{
            cb(null, data);
        }
    });
}

module.exports = sendMail;




