const express = require("express");
const port = 7000;
const ejs = require('ejs');
const sendMail = require('./mail');
const mongoose = require('mongoose');
const User = require('./models/Users');
mongoose.connect("mongodb://localhost:27017/userDB", {useNewUrlParser: true, useUnifiedTopology:true});
const bodyParser = require('body-parser');
const session = require('express-session');
const flush = require('connect-flash');
const path = require('path');

const app = express();

app.use(express.static("views"));
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({extended: true}));
app.use(session({
    secret: 'secret',
    cookie: {maxAge : 60000},
    resave: false,
    saveUninitialized: false
}));

app.use(flush());

app.get("/", (req, res) => {

    res.render("index");

})


app.get("/register", (req, res) => {

    res.render("register", { message : req.flash('message')});

});

app.get("/login", (req, res) => {

    res.render("login", { message : req.flash('message')});

});

app.get("/land", (req, res) => {

    res.render("land", { message : req.flash('message')});

});

app.get("/movies", (req, res) => {

    res.render("movies");

})

app.get("/tv", (req, res) => {

    res.render("tv");

})
app.get("/aboutus", (req, res) => {

    res.render("aboutus");

})
//reqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq

app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.post('/email', (req, res) =>{

    const { subject, email, text } = req.body;
    console.log('data: ', req.body);
   
    sendMail(email, subject, text, function(err, data){
        if(err){
            res.status(500).json({message: 'error'});
        }
        else {
            res.json({ message: 'email sent!!'});
          
        }

       

    });

   
});




app.get('/request', (req, res) =>{

    res.render('request')

})






//11111111111111111111111111111111111111111111111111111111
app.post('/register', (req, res) => {
    const firstname = req.body.firstname;
    const lastname = req.body.lastname;
    const email = req.body.email;
    const password = req.body.password;

    const newUser = new User({
        firstname: firstname,
        lastname: lastname,
        email: email,
        password: password
    })

    newUser.save((err) => {

        if(err) {
            console.log(err);
        }
        else{
            req.flash('message', 'Registered Successfully!!');
            res.redirect('login');
        }

        
    })

});

app.post('/login', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    User.findOne({email: email}, (err, foundResults)=>{
        if(err) {
            console.log(err);
        }
        else{
            if(foundResults.password === password) {
                
                req.flash('message', 'login Successfully!!');
                res.redirect('land');
            }

            else{
                req.flash('message', 'Invalid Email or Password');
                res.redirect('login');
            }
        }
    })
});
// ----------------------------------------------All Files ---------------------------------------
app.get("/101", (req, res) => {res.render("101");})
app.get("/102", (req, res) => {res.render("102");})
app.get("/103", (req, res) => {res.render("103");})
app.get("/104", (req, res) => {res.render("104");})
app.get("/105", (req, res) => {res.render("105");})
app.get("/106", (req, res) => {res.render("106");})
app.get("/107", (req, res) => {res.render("107");})
app.get("/108", (req, res) => {res.render("108");})
app.get("/201", (req, res) => {res.render("201");})
app.get("/202", (req, res) => {res.render("202");})
app.get("/203", (req, res) => {res.render("203");})
app.get("/204", (req, res) => {res.render("204");})
app.get("/205", (req, res) => {res.render("205");})
app.get("/206", (req, res) => {res.render("206");})
app.get("/207", (req, res) => {res.render("207");})
app.get("/208", (req, res) => {res.render("208");})
app.get("/209", (req, res) => {res.render("209");})
app.get("/210", (req, res) => {res.render("210");})
app.get("/211", (req, res) => {res.render("211");})
app.get("/212", (req, res) => {res.render("212");})
app.get("/213", (req, res) => {res.render("213");})
app.get("/214", (req, res) => {res.render("214");})
app.get("/215", (req, res) => {res.render("215");})
app.get("/216", (req, res) => {res.render("216");})
app.get("/217", (req, res) => {res.render("217");})
app.get("/218", (req, res) => {res.render("218");})
app.get("/219", (req, res) => {res.render("219");})
app.get("/220", (req, res) => {res.render("220");})
app.get("/221", (req, res) => {res.render("221");})
app.get("/222", (req, res) => {res.render("222");})
app.get("/223", (req, res) => {res.render("223");})
app.get("/224", (req, res) => {res.render("224");})
app.get("/225", (req, res) => {res.render("225");})
app.get("/226", (req, res) => {res.render("226");})
app.get("/227", (req, res) => {res.render("227");})
app.get("/228", (req, res) => {res.render("228");})
app.get("/229", (req, res) => {res.render("229");})
app.get("/230", (req, res) => {res.render("230");})
app.get("/231", (req, res) => {res.render("231");})
app.get("/232", (req, res) => {res.render("232");})
app.get("/301", (req, res) => {res.render("301");})
app.get("/302", (req, res) => {res.render("302");})
app.get("/303", (req, res) => {res.render("303");})
app.get("/304", (req, res) => {res.render("304");})
app.get("/305", (req, res) => {res.render("305");})
app.get("/306", (req, res) => {res.render("306");})
app.get("/307", (req, res) => {res.render("307");})
app.get("/308", (req, res) => {res.render("308");})
app.get("/309", (req, res) => {res.render("309");})
app.get("/310", (req, res) => {res.render("310");})
app.get("/311", (req, res) => {res.render("311");})
app.get("/312", (req, res) => {res.render("312");})
app.get("/313", (req, res) => {res.render("313");})
app.get("/314", (req, res) => {res.render("314");})
app.get("/315", (req, res) => {res.render("315");})
app.get("/316", (req, res) => {res.render("316");})
app.get("/317", (req, res) => {res.render("317");})
app.get("/318", (req, res) => {res.render("318");})
app.get("/319", (req, res) => {res.render("319");})
app.get("/320", (req, res) => {res.render("320");})
app.get("/321", (req, res) => {res.render("321");})
app.get("/322", (req, res) => {res.render("322");})
app.get("/323", (req, res) => {res.render("323");})
app.get("/324", (req, res) => {res.render("324");})
app.get("/325", (req, res) => {res.render("325");})
app.get("/326", (req, res) => {res.render("326");})
app.get("/327", (req, res) => {res.render("327");})
app.get("/328", (req, res) => {res.render("328");})
app.get("/329", (req, res) => {res.render("329");})
app.get("/330", (req, res) => {res.render("330");})
app.get("/331", (req, res) => {res.render("331");})
app.get("/332", (req, res) => {res.render("332");})


app.listen(port, () => console.log('server started'))